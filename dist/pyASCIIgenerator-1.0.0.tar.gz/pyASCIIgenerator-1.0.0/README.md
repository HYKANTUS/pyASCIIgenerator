# pyASCIIgenerator
A simple image-to-ASCII converter based on a video by [Kite](https://www.youtube.com/watch?v=v_raWlX7tZY).

## Usage
```python
import pyASCIIgenerator
pyASCIIgenerator.asciify('path \\\ to \\\ file')
```

**REMEMBER TO USE DOUBLE BACKSLASHES**

**_also try:_**
```python
import pyASCIIgenerator
pyASCIIgenerator.help()
```
_this will print out the usage example_


## Requirements
this module relies on the [PIL.Image](https://pillow.readthedocs.io/en/stable/reference/Image.html) from the library, Pillow.
## Credits
Made by [HYKANTUS](http://www.hykantus.tk)
